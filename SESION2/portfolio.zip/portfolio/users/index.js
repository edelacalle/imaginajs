import { Usuarios } from "./oUsers.js"

var oUser = new Usuarios();


//var intervalID = setInterval(oUser.saveFileUsers, 100);

var me = oUser;


//oUser.addUser('ADmin',"pues yo", [{"usd":1}])
//oUser.addUser('antonio4',"pass lopez", [{"usd":2}])

//oUser.delUser('antonio2',"pass lopez");
//oUser.updUser('ecalle','ecalle',[{"msg":"cambiame"}])

// setInterval(oUser.saveFileUsers.bind(oUser) , 1000);



//oUser.saveFileUsers();





//console.log("los usuarios son ", JSON.stringify(oUser.users, null, " "))

//oUser.users["nuevo"] = {};



//oUser.saveFileUsers();
//console.log("test", oUser.getName )

