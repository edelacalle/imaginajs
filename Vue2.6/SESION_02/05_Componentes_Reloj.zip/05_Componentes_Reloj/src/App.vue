<template>
  <div>
    
    <Cabecera msg="relojes del Mundo"></Cabecera>
    <table border="1px" >
      <thead>
        <tr>
          <th>
            <button @click="lAdd=true">Add Reloj</button>
          </th>
          <th >Max: Id {{ maxId }}</th>
          <th >Nº Relojes {{ relojes.length }}</th>
        </tr>
      </thead>
        
    </table>
    <br/>
    <br/>
      <template v-if="lAdd">

          <label>Añadir reloj</label>
          <select ref="ecs1" id="myref1">
            <option>Europe/Andorra</option>
            <option>Asia/Dubai</option>
            <option>Asia/Kabul</option>
            <option>Europe/Tirane</option>
            <option>Asia/Yerevan</option>
            <option>Antarctica/Davis</option>
          </select>
          <button @click="addReloj" >Add</button>
    </template>
    
    <br/>
    <br/>

    <table border="1px" >
      <thead>
        <tr>
          <th v-for="e in relojes" :key="e.id">{{ e.title }}</th>
        </tr>
      </thead>

      <tbody>
        <tr>
          <td v-for="e in relojes" :key="e.id">
            <Reloj
              :id       = "e.id"
              :title    = "e.title"
              :timezone = "e.timezone"
              v-on:onTerremoto = "infoTerremoto"
            >
            </Reloj></td>
        </tr>
      </tbody>
      <tfoot>
        <tr>
          <th v-for="e in relojes" :key="e.id"><button v-on:click="killReloj(e.id)">Borrar:{{ e.id}} </button></th>
          
        </tr>
      </tfoot>
    </table>
    <hr/>
    
    
    <textarea rows="10"  cols="100" :value="JSON.stringify(aLogs,null,' ')"></textarea>
    <hr/>
    <button @click="test">test</button>
  </div>
</template>

<script>

import Cabecera from './components/Cabecera.vue';
import Reloj from './components/Reloj.vue'

export default {
  name: 'App',
  components: {  Cabecera, Reloj  },
  data(){
    return {
      aLogs:[],
      lAdd:false,
      relojes:[
        {id:1, title:"Madrid", timezone:"Europe/Madrid"},
        {id:2, title:"Londres", timezone:"Europe/London"},
        {id:3, title:"Nueva York", timezone:"America/New_york"},
        {id:4, title:"Jakarta", timezone:"Asia/Jakarta"},
        {id:5, title:"Tokyo", timezone:"Asia/Tokyo"},
        {id:6, title:"Sydney", timezone:"Australia/Sydney"},
      ],
    }
  },
  computed:{
    maxId: {
    // getter
    get: function () {
        return this.relojes.reduce((p, v) => p.id < v.id ? p.id : v.id )
    },
    // setter
    set: function () {
    }
  }

  },
  methods:{
    
    killReloj(id){
      this.relojes = this.relojes.filter(r=>r.id!=id);
    },
    addReloj(){
      // INFO: Opcion mas sencilla , mediante document.getElementById("myref1").value
      // INFO: Opcion vue this.$refs['ecs1'].value , poniendo el attributo refs 
      
      // let timezone = document.getElementById("myref1").value;
      let timezone = this.$refs['ecs1'].value;

      // INFO: Busco un id +1 
      // INFO: Opcion mas sencilla  , manipulando el array arelojes para encontrar el maximo
      // INFO: opcion vue usando una funcion computed 
           
      // let maxId = this.relojes.reduce((p, v) => p.id < v.id ? p.id : v.id );

      //this.relojes.push({id:++maxId,title:timezone.split('/').pop(), timezone : timezone})
      this.relojes.push({id:++this.maxId,title:timezone.split('/').pop(), timezone : timezone})
      this.lAdd = false;

    },
    infoTerremoto(payload){
      console.log("llega un terremoto", payload)
      this.aLogs.push(payload)
      //payload.title = "PUMP"
    },
    test(){
      this.$children[2].title ="Padre cambia Hijo 2";
      this.$children[2].timezone ="Europe/Madrid";
      /*
      this.$children.forEach((e)=>{
        e.ahora=""
        //e.timezone ="Europe/Madrid";
      })
      */
      //console.log("test", this.$children[5].ahora)
    }
    
  }
}
</script>

<style scoped>
 h4  { color:red }
 table {width: 100%; border: 2px solid blue }
 tr {border: 2px solid blue}

</style>
