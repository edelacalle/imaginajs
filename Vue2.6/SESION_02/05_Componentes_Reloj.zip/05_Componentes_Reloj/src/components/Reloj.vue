<!--
  INFO: Dos alternativas para hacer el boton de toggle 
    1.- con condicional en el texto {{lRun?'Parar':'Arrancar'}} 
    2.- usando v-if , v-else 
    Uso v-show para ocultar / mostrar items , no es necesairo
-->
<template>
  <div>
      <p>{{ ahora }}</p>
      
      <div v-if="hora >= 20">
          <p>Buenas Noches {{ title }}</p>
      </div>
      <div v-else-if="hora >= 12 ">
        <p>Buenas tardes {{ title }}</p>
      </div>
      <div v-else>
        <p>Buenos dias {{ title }} </p>
      </div>
     
      <button v-show="true" v-on:click="terremoto">Terremoto</button>
      

  </div>
</template>

<script>
export default {
  name: 'MiReloj',
  props:['id','title','timezone'],
  data(){
      return{
          ahora: null,
          hora:0,
      }
  },
  mounted(){
    this.timer = setInterval(this.tick.bind(this), 1000)
  },

  beforeDestroy() {
      
      clearInterval(this.timer)
      if(this.envia){this.envia(`Contador ${this.id} destruido`)}
  },
  
  methods:{
      tick(){
        this.ahora = new Date().toLocaleString("es-ES", {timeZone: this.timezone})
        this.hora = new Date( this.ahora).getHours();
      },
      terremoto(){
        this.$emit('onTerremoto', {id:this.id, title:this.title , time:this.ahora} );
      } 
  }
}
</script>

<style scoped>
  h4 {color: burlywood;}
  h5 {color:darkblue}
</style>