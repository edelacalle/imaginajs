<template>
  <v-app>
    <v-app-bar
      app
      color="primary"
      dark
    >
      
      <v-btn @click="layout='main-layout'" small elevation="5" color="success" >
        <v-icon>mdi-home</v-icon>Inicio
      </v-btn>
      <v-spacer />
      <v-btn @click="layout='login-layout'" small elevation="2" >
        <v-icon >mdi-login</v-icon>Login
      </v-btn>
      <v-spacer />
      <v-btn @click="layout='register-layout'" small elevation="2" >
        <v-icon>mdi-account-plus</v-icon>Register
      </v-btn>
    </v-app-bar>
    <v-main>
      <component :is="layout"></component>
    </v-main>
  </v-app>
  

</template>
<script>


import MainLayout from './components/layouts/MainLayout.vue';
import LoginLayout from './components/layouts/LoginLayout.vue';
import RegisterLayout from './components/layouts/RegisterLayout.vue';

export default {
  name: 'App',
  components: {MainLayout, LoginLayout, RegisterLayout},
  data: () => ({layout:'main-layout'}),
};
</script>
