<template>
  <div>
    <p>Registro Layout</p>
  </div>
</template>


<script>

export default {
  name: 'register-layout',
  components: {},
  data: () => ({
    //
  })
};
</script>