
<template>
   <h1>Login Layout</h1>
</template>

<script>
export default {
 name: 'login-layout',
 data() {
   return {
   
   };
 },
};
</script>


