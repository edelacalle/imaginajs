<template>
  <div  >
    <p>Main Layout {{ Date.now() }}</p>
  </div>
</template>


<script>
export default {
  name: 'main-layout',
  components: {},
  data: () => ({
  }),
};
</script>