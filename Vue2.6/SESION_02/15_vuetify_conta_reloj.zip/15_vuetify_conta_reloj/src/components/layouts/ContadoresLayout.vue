
<template>
  <div>
    
    <v-alert
      border="top"
      color="info lighten-2"
      dark
    >
      Contadores
    </v-alert>
    <v-simple-table>
      <template v-slot:default>
        <thead>
          <tr>
            <th class="text-left">
              Titulo
            </th>
            <th class="text-left">
              Contador
            </th>
          </tr>
        </thead>
        <tbody>
          <tr
            v-for="contador in contadores"
            :key="contador.id"
          >
            <td>{{ contador.title }}</td>
            <td><Contador
                :id = "contador.id"
                v-bind:inicio="contador.inicio"
              ></Contador></td>
          </tr>
        </tbody>
      </template>
    </v-simple-table>

  </div>
</template>

<script>


import Contador from '../Contador.vue';


export default {
 name: 'contadores-layout',
 components: {  Contador  },
 data() {
   return {
      contadores :[
        {id:1, title:"CPD 1", inicio:0},
        {id:2, title:"CPD 2", inicio:120},
        {id:3, title:"CPD 3", inicio:890},
        {id:4, title:"CPD 4", inicio:0},
      ]
   
   };
 },
};
</script>


