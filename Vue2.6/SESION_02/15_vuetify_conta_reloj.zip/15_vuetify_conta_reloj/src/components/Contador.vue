<!--
  INFO: Dos alternativas para hacer el boton de toggle 
    1.- con condicional en el texto {{lRun?'Parar':'Arrancar'}} 
    2.- usando v-if , v-else 
    Uso v-show para ocultar / mostrar items , no es necesairo
-->
<template>
  <div>
      <v-btn @click="toggle" small elevation="2" >
        <v-icon >{{lRun?'mdi-stop':'mdi-play'}} `mdi-stop</v-icon>
      </v-btn>
    
      <v-btn @click="valor=inicio" small elevation="2" >
        <v-icon >mdi-restart</v-icon>
      </v-btn>
      <v-chip dark outlined class="ml-4" :color="(lRun)?'purple':'red'" >{{ valor }}</v-chip>
  </div>
</template>

<script>
export default {
  name: 'MiContador',
  props:['id','inicio'],
  data(){
      return{
          valor: 0,
          lRun:true
      }
  },
  mounted(){
    this.timer = setInterval(this.tick.bind(this), 1000)
    this.valor =  this.inicio ?? 0;
  },

  beforeDestroy() {
      clearInterval(this.timer)
  },
  
  methods:{
      tick(){
          if(this.lRun){
             this.valor++;
          }
      },
      toggle(){
          this.lRun = !this.lRun;
      },
      resetear(){
        this.valor =  this.inicio;
      } 
  }
}
</script>

<style scoped>
</style>