
<template>
  <div>

      
      <div v-if="hora > 20">
          <p>Buenas Noches {{ title }}</p>
      </div>
      <div v-else-if="hora >12 ">
        <p>Buenas tardes {{ title }}</p>
      </div>
      <div v-else>
        <p>Buenos dias {{ title }} </p>
      </div>
     
      <p>{{ ahora }}</p>      
      

  </div>
</template>

<script>
export default {
  name: 'MiReloj',
  props:['id','title','timezone'],
  data(){
      return{
          ahora: null,
          hora:0,
      }
  },
  mounted(){
    this.timer = setInterval(this.tick.bind(this), 1000)
  },

  beforeDestroy() {
      clearInterval(this.timer)

  },
  
  methods:{
      tick(){
        this.ahora = new Date().toLocaleString("es-ES", {timeZone: this.timezone})
        this.hora = new Date( this.ahora).getHours();
      },
  }
}
</script>

<style scoped>
</style>