<template>
  <v-app>
    <v-app-bar
      app
      color="primary"
      dark
    >
      
      <v-btn @click="layout='main-layout'" small elevation="5" color="success" >
        <v-icon>mdi-home</v-icon>Inicio
      </v-btn>
      <v-spacer />
      <v-btn @click="layout='contadores-layout'" small elevation="2" >
        <v-icon >mdi-alarm</v-icon>Contadores
      </v-btn>
      <v-spacer />
      <v-btn @click="layout='relojes-layout'" small elevation="2" >
        <v-icon>mdi-clock</v-icon>Relojes
      </v-btn>
    </v-app-bar>
    <v-main>
      <component :is="layout"></component>
    </v-main>
  </v-app>
  

</template>
<script>


import MainLayout from './components/layouts/MainLayout.vue';
import RelojesLayout from './components/layouts/RelojesLayout.vue';
import ContadoresLayout from './components/layouts/ContadoresLayout.vue';

export default {
  name: 'App',
  components: {MainLayout, RelojesLayout, ContadoresLayout},
  data: () => ({layout:'main-layout'}),
};
</script>
