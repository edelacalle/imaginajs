<!--
  INFO: Dos alternativas para hacer el boton de toggle 
    1.- con condicional en el texto {{lRun?'Parar':'Arrancar'}} 
    2.- usando v-if , v-else 
    Uso v-show para ocultar / mostrar items , no es necesairo
-->
<template>
  <div>
      <h4>Id {{ id }}</h4>
      <h5>Valor {{ valor }}</h5>

      <!--
      <button v-if="lRun" v-on:click="toggle" >Parar</button>
      <button v-else v-on:click="toggle" >Arrancar</button>
      -->

      <button v-show="true" v-on:click="toggle">{{lRun?'Parar':'Arrancar'}} </button>
      <button v-show="true" @click="resetear">Resetea</button>

  </div>
</template>

<script>
export default {
  name: 'MiContador',
  props:['id','inicio','envia'],
  data(){
      return{
          valor: 0,
          lRun:true
      }
  },
  mounted(){
    this.timer = setInterval(this.tick.bind(this), 1000)
    this.valor =  this.inicio ?? 0;
      
  },

  beforeDestroy() {
      this.paraContador();
      if(this.envia){this.envia(`Contador ${this.id} destruido`)}
  },
  
  methods:{
      paraContador () {
          clearInterval(this.timer)
      },
      tick(){
          if(this.lRun){
             this.$emit('onEnviame', `Papa , soy el contador ${this.id} con el valor ${this.valor}`);
             this.valor++;
          }
      },
      toggle(){
          this.lRun = !this.lRun;
      },
      resetear(){
        this.valor =  this.inicio;
        if(this.envia){
          this.envia("reseteo")
        }
      } 
  }
}
</script>

<style scoped>
  h4 {color: burlywood;}
  h5 {color:darkblue}
</style>