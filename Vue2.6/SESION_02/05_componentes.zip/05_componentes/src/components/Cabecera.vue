<template>
  <div id="id-cab">
    <h1> {{msg}} </h1>  
  </div>
</template>

<script>
export default {
  name: 'CabeceraComponent',
  props: ['msg']
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
  #id-cab {background-color:beige}
  #id-cab > h1 {color:burlywood }
</style>
