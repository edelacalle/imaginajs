<template>
  <div>
    <h4>Aplicacion principal con el estilo aplicado en app.vue h4: Color red </h4>

    <Cabecera msg="Grid de Contadores con su propio estilo"></Cabecera>

    <table border="1px" >
      <thead>
        <tr>
          <th v-for="e in contadores" :key="e.id">{{ e.title }}</th>
          
        </tr>
      </thead>

      <tbody>
        <tr>
          <td v-for="e in contadores" :key="e.id">
            <Contador 
              :id = "e.id"
              v-bind:inicio="e.inicio"
              v-on:onEnviame = "reciboMsgHijos"
              :envia = "reciboMsgHijos"
               >
            </Contador></td>
        </tr>
      </tbody>
      <tfoot>
        <tr>
          <th v-for="e in contadores" :key="e.id"><button v-on:click="killContador(e.id)">Borrar:{{ e.id}} </button></th>
          
        </tr>
      </tfoot>
    </table>
    <hr/>
    <textarea rows="10"  cols="100" :value="logs"></textarea>
    
    
  </div>
</template>

<script>

import Cabecera from './components/Cabecera.vue';
import Contador from './components/Contador.vue';


export default {
  name: 'App',
  components: {  Cabecera, Contador  },
  data(){
    return {
      logs:"",
      contadores :[
        {id:1, title:"CPD 1", inicio:0},
        {id:2, title:"CPD 2", inicio:120},
        {id:3, title:"CPD 3", inicio:890},
        {id:4, title:"CPD 4", inicio:0},
      ]
    }
  },
  methods:{
    reciboMsgHijos(msg){
      //console.log("recibo de los hijos", msg)
      this.logs += msg + '\n';

    },
    killContador(id){
      this.contadores = this.contadores.filter(r=>r.id!=id);
    },
    cambiaValor(){
      this.contadores.pop();
    }
  }
}
</script>

<style scoped>
  h4  { color:red }
 
 
 table {width: 100%; border: 2px solid blue }
 tr {border: 2px solid blue}

</style>
