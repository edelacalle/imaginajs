import Vue from 'vue'
import App from './App.vue'

Vue.config.productionTip = false

Vue.directive('focus', {
  // Cuando el elemento enlazado se inserta en el DOM...
  inserted: function (el) {
    // Enfoca el elemento
    el.focus();
    el.style.backgroundColor = "red"
  }
})

window.vm = new Vue({
  render: h => h(App),
}).$mount('#app')


