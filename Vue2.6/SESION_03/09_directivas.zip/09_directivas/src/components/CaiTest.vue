<template>
  <div>
      <span>CaiTest</span>
      <input  value="" />
      <input  value="" />
 
      <input v-focus value="Campo con el foco" />
  </div> 
</template>

<script>
  export default {
    name: 'cai-test',
    props: {
      msg: String
    }
  }
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
