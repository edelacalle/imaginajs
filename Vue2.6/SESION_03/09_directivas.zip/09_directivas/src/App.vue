<template>
  <div id="app">
      <p>{{ title }}</p>
      <cai-test></cai-test>
</div>
</template>

<script>
// import HelloWorld from './components/HelloWorld.vue'
import CaiTest from './components/CaiTest.vue'


export default {
  name: 'App',
  data(){
    return {
      title:"Titulo de App"
    }
  },
  components: {
    CaiTest
  }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
