<template>
  <v-app>
    <v-app-bar
      app
      color="primary"
      dark
    >
      
      <v-btn @click="layout='main-layout'" small elevation="5" color="success" >
        <v-icon>mdi-home</v-icon>Inicio
      </v-btn>
      <v-spacer />
      <v-btn @click="layout='boton-layout'" small elevation="2" >
        <v-icon >mdi-login</v-icon>boton
      </v-btn>
      <v-spacer />
      <v-btn @click="layout='lista-layout'" small elevation="2" >
        <v-icon>mdi-account-plus</v-icon>Lista
      </v-btn>
    </v-app-bar>
    <v-main>
      <component :is="layout"></component>
    </v-main>
  </v-app>
  

</template>
<script>


import BotonLayout from './components/layouts/BotonLayout.vue';
import ListaLayout from './components/layouts/ListaLayout.vue';
import MainLayout from './components/layouts/MainLayout.vue';

export default {
  name: 'App',
  components: {BotonLayout, ListaLayout, MainLayout},
  data: () => ({layout:'main-layout'}),
};
</script>./components/layouts/BotonLayout.vue./components/layouts/ListaLayout.vue
