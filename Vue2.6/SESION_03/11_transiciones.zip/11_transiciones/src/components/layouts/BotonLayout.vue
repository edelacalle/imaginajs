
<template>
  <div id="demo">
    <v-btn v-on:click="show = !show">
      {{show?'Ocultar':'Mostrar'}}
    </v-btn>
    <hr/>
    <transition name="fade" mode="out-in">
        <v-btn v-if="show">Hola</v-btn>
    </transition>
    <hr/>
  </div>


</template>

<script>
export default {
 name: 'boton-layout',
 data() {
   return {
    show:true

   };
 },
};
</script>


<style>
  .fade-enter-active, .fade-leave-active {
    transition: opacity .5s
  }
  .fade-enter, .fade-leave-to  {
    opacity: 0
  }
</style>

