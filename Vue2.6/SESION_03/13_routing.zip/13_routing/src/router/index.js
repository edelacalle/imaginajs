import Vue from 'vue'
import VueRouter from 'vue-router'
import HomeView from '../views/HomeView.vue'

import ClientesView from '../views/ClientesView.vue';
import ProveedoresView from '../views/ProveedoresView.vue' 
import NotFoundView from '../views/NotFoundView.vue'

Vue.use(VueRouter)

const routes = [
  { path: '/404', component: NotFoundView },  

  {
    path: '/clientes/:id',
    name: 'clientes',
    component: ClientesView
  },
  
  {
    path: '/proveedores',
    name: 'proveedores',
    component: ProveedoresView
  },
  {
    path: '/',
    name: 'home',
    component: HomeView
  },
  {
    path: '/about',
    name: 'about',
    component: () => import('../views/AboutView.vue')
  },
  { path: '*',  redirect: '/404' }
]

const router = new VueRouter({
  routes
})

export default router
