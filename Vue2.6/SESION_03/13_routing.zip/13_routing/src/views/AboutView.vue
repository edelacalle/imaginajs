<template>
  <div class="about">
    <h1>About es de carga perezosa </h1>
  </div>
</template>



<script>
// @ is an alias to /src
//import HelloWorld from '@/components/HelloWorld.vue'

export default {
  name: 'AboutView',
  components: {
  //  HelloWorld
  },
  created(){
    console.log("evento creado")
  }

}
</script>
