<template>
  <div class="home">
      <p>View Clientes</p>
      <div>Params {{ $route.params.id }}</div>
  
  </div>
</template>

<script>
// @ is an alias to /src
//import HelloWorld from '@/components/HelloWorld.vue'

export default {
  name: 'ClientesView',
  components: {
    // HelloWorld
  },
  constructor(){
    console.log("constructor Clientes created")
  },
  created(){
    
  }
}
</script>
