<template>
  <div class="home">
      <p>View Proveedores</p>
  
  </div>
</template>

<script>
// @ is an alias to /src
//import HelloWorld from '@/components/HelloWorld.vue'

export default {
  name: 'ProveedoresView',
  components: {
    // HelloWorld
  }
}
</script>
