<template>
  <div >
    <h1>Url No encontrada (Personalizada)</h1>
  </div>
</template>
