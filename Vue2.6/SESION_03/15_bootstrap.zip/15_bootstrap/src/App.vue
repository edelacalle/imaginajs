<template>
  <div>
    <b-alert variant="success" show>Hola Mundo</b-alert>
  </div>
</template>

<script>


export default {
  name: 'App',
  components: {

  }
}
</script>

<style>

</style>
