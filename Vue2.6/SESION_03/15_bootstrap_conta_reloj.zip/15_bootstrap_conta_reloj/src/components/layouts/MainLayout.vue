<template>
  <div>
    
    <b-alert variant="success" show>Alert de la pagina principal</b-alert>
  </div>
</template>


<script>
export default {
  name: 'main-layout',
  components: {},
  data: () => ({
  }),
};
</script>