<template>
    <b-container>
    <b-row>
      <b-col>Titulo</b-col>
      <b-col>Reloj</b-col>
    </b-row>
    <b-row v-for="reloj in relojes" :key="reloj.id" class="b-1">
      <b-col>{{reloj.title}}</b-col>
      <b-col>
        <Reloj
          :id       = "reloj.id"
          :title    = "reloj.title"
          :timezone = "reloj.timezone"
        >
        </Reloj>
      </b-col>
      
    </b-row>
  </b-container>
  
</template>

<script>

import Reloj from '../Reloj.vue';

export default {
  name: 'relojes-layout',
  components: {Reloj},
  data: () => ({
    relojes:[
        {id:1, title:"Madrid", timezone:"Europe/Madrid"},
        {id:2, title:"Londres", timezone:"Europe/London"},
        {id:3, title:"Nueva York", timezone:"America/New_york"},
        {id:4, title:"Jakarta", timezone:"Asia/Jakarta"},
        {id:5, title:"Tokyo", timezone:"Asia/Tokyo"},
        {id:6, title:"Sydney", timezone:"Australia/Sydney"},

      ],
  })
};
</script>