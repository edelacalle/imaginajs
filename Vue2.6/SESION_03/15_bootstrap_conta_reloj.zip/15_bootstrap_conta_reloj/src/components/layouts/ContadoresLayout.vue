<template>
  <b-container>
    <b-table hover :items="contadores" >
      <template #cell(inicio)="contador">
        <Contador
          :id = "contador.id"
           v-bind:inicio="contador.value"
        ></Contador> 
      </template>
    </b-table>
  </b-container>
</template>
<script>

import Contador from '../Contador.vue';

export default {
 name: 'contadores-layout',
 components: {Contador},
 data() {
   return {
      contadores :[
        {id:1, title:"CPD 1", inicio:0},
        {id:2, title:"CPD 2", inicio:120},
        {id:3, title:"CPD 3", inicio:890},
        {id:4, title:"CPD 4", inicio:0},
      ]
   
   };
 },
};
</script>


