<template>
  <b-container>
    <b-button @click="valor=inicio" class="m-1" variant="outline-info">
      <b-icon-arrow-clockwise/>
    </b-button>
    <b-button class="p-2 m-1" @click="toggle" raised outline  :variant="lRun?'warning':'danger'">
      <b-icon-play v-if="lRun == false" ></b-icon-play>
      <b-icon-stop v-else></b-icon-stop>
      {{ valor }}
    </b-button>
    
    
  </b-container>


</template>
<script>
export default {
  name: 'MiContador',
  props:['id','inicio'],
  data(){
      return{
          valor: 0,
          lRun:true
      }
  },
  mounted(){
    this.timer = setInterval(this.tick.bind(this), 1000)
    this.valor =  this.inicio ?? 0;
  },

  beforeDestroy() {
      clearInterval(this.timer)
  },
  
  methods:{
      tick(){
          if(this.lRun){
             this.valor++;
          }
      },
      toggle(){
          this.lRun = !this.lRun;
      },
      resetear(){
        this.valor =  this.inicio;
      } 
  }
}
</script>

<style scoped>
</style>