<template>
  <div id="app" >
    <nav class="navbar navbar-light bg-light">
      <a class="navbar-brand" href="#" @click="layout='main-layout'" > Inicio</a>
      <b-button @click="layout='contadores-layout'" class="p-2 m-2" variant="primary">Contadores</b-button>
      <b-button @click="layout='relojes-layout'" class="p-2 m-2" variant="success">Relojes</b-button>  
    </nav>
    <component :is="layout"></component>
  </div>
</template>

<script>
  import MainLayout from './components/layouts/MainLayout.vue';
  import RelojesLayout from './components/layouts/RelojesLayout.vue';
  import ContadoresLayout from './components/layouts/ContadoresLayout.vue';

  export default {
    name: 'App',
    components: {MainLayout, RelojesLayout, ContadoresLayout},
    data: () => ({layout:'main-layout'}),
  };

</script>

<style>
</style>
