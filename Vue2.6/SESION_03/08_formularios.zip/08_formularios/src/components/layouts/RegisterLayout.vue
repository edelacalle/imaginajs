
<template>
  <v-app >
     <v-main>
        <v-container fluid fill-height>
           <v-layout align-center justify-center>
              <v-flex xs12 sm8 md4>
                 <v-card class="elevation-12">
                    <v-toolbar dark color="primary">
                       <v-toolbar-title>Registro Usuario</v-toolbar-title>
                    </v-toolbar>
                    <v-card-text>
                    <form ref="form" @submit.prevent="login()">
                           <v-text-field
                             v-model="username"
                             name="username"
                             label="Username"
                             type="text"
                             placeholder="usuarios"
                             required
                          ></v-text-field>
                          
                           <v-text-field
                             v-model="password1"
                             name="password"
                             label="Password"
                             type="password"
                             placeholder="password"
                             required
                          ></v-text-field>
                          <v-text-field
                             v-model="password2"
                             name="password"
                             label="Password"
                             type="password"
                             placeholder="repite password"
                             required
                          ></v-text-field>
                          <v-btn :disabled="!lFormOk" type="submit" class="mt-4" color="primary" value="log in">Login</v-btn>
                     </form>
                     
                    </v-card-text>
                 </v-card>
                 <v-card class="elevation-12" v-show="!lFormOk">
                  <v-toolbar dark color="error">
                       <v-toolbar-title>Errores</v-toolbar-title>
                    </v-toolbar>
                    <v-card-text>
                      {{ errores }}
                    </v-card-text>
                  </v-card>
              </v-flex>
           </v-layout>
        </v-container>
     </v-main>
  </v-app>
</template>


<script>

export default {
  name: 'register-layout',
  components: {},
  data: () => ({
    errores: {  notempty:"Contraseña vacia"  },
    username:"",
    password1:"",
    password2:"",
    lFormOk: false
  }),
  computed:{
    
  },
  watch: {
    password1: function (val) {
      if (this.password2 != val) {
        this.errores["notequal"] = 'Diferentes'
      }else{
        delete this.errores["notequal"]
      }
      if (val.length=="") {
        this.errores["notempty"] = 'Vacia'
      }else{
        delete this.errores["notempty"]
      }
      this.lFormOk =  Object.keys(this.errores).length == 0 
      
    },
    password2: function (val) {
      if (this.password1 != val) {
        this.errores["notequal"] = 'Diferentes'
      }else{
        delete this.errores["notequal"]
      }
      if (val.length=="") {
        this.errores["notempty"] = 'Vacia'
      }else{
        delete this.errores["notempty"]
      }
      this.lFormOk =  Object.keys(this.errores).length == 0 

    }
  }
};
</script>