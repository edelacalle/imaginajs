import Vue from 'vue'

export default (context) => {
  Vue.filter('traslate', function (value) {
     if (!value) return '';
     return context.store.getters.translate(value);
  })
 
  Vue.directive('traslate', {
    bind: function (el,binding) {
      el.innerText = context.store.getters.translate(binding.value);
    }
  })
}