<template>
  <div>
    <v-simple-table>
      <template v-slot:default>
        <thead>
          <tr>
            <th class="text-left">
              Titulo
            </th>
            <th class="text-left">
              Contador
            </th>
          </tr>
        </thead>
        <tbody>
          <tr
            v-for="e in relojes"
            :key="e.id"
          >
            <td>{{ e.title }}</td>
            <td> <Reloj
              :id       = "e.id"
              :title    = "e.title"
              :timezone = "e.timezone"
            >
            </Reloj>
              </td>
          </tr>
        </tbody>
      </template>
    </v-simple-table>
  </div>
</template>

<script>

import Reloj from '../components/reloj.vue';

export default {
  name: 'relojes-layout',
  components: {Reloj},
  data: () => ({
    relojes:[
        {id:1, title:"Madrid", timezone:"Europe/Madrid"},
        {id:2, title:"Londres", timezone:"Europe/London"},
        {id:3, title:"Nueva York", timezone:"America/New_york"},
        {id:4, title:"Jakarta", timezone:"Asia/Jakarta"},
        {id:5, title:"Tokyo", timezone:"Asia/Tokyo"},
        {id:6, title:"Sydney", timezone:"Australia/Sydney"},
      ],
  })
};
</script>