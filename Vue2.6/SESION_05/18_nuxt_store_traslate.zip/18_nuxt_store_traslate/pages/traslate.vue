<!-- eslint-disable vue/comment-directive -->
<template>
  <v-layout>
    
    
    <v-card>
      <v-toolbar>
        <v-btn @click="setLang('en')" type="button" class="mt-4" color="primary" >English</v-btn>
        <v-btn @click="setLang('es')" type="button" class="mt-4" color="primary" >Spanish</v-btn>

      </v-toolbar>
      <v-card-text>
        <br/>
        <p>[ {{ this.$store.getters.translate('home') }} ]</p>
        <p>Con filtro {{ 'home' | traslate   }}</p>
        <p>Con directiva <span :key="nChanges" v-traslate="'home'"></span></p>
        <br>
      </v-card-text>
    </v-card>

    
  </v-layout>
</template>


<script>

export default {
  name: 'traslate-layout',
  data: () => ({
    nChanges:0
    
  }),
  created(){
    let me = this;
    this.unsubscribe = this.$store.subscribe((mutation, state) => {
      me.nChanges ++;
    })
  },
  beforeDestroy() {
    this.unsubscribe();
  },
  methods:{
    setLang(lang){
      this.$store.commit('changeLanguage',lang) 
    }
  },

  /*
  async fetch(){
  
  }
  */
};
</script>




