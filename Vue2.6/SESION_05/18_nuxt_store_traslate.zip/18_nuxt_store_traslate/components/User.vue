
<template>
  <div>
      <v-btn   icon >
        <v-icon>mdi-account</v-icon>
      </v-btn>
      [{{ $store.state.username }}]
  </div>
</template>

<script>
export default {
  name: 'MiUser',
  props:[],
  data(){
      return{
      }
  },
  mounted(){
  },

  beforeDestroy() {
  
  },
  
  methods:{
  }
}
</script>

<style scoped>
</style>