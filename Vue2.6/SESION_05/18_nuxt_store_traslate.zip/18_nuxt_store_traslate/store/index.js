  // holds your root state
  export const state = () => ({
    i18n: require('./traslate.json'),
    languages:['en','es'],
    language:"es",
    update:false,
    alumnos:[
      {id:1, name:"alumno1"},
      {id:2, name:"alumno2"}
    ]
  })
  
  // contains your actions
  export const actions = {
  }
  
  // contains your mutations
  export const mutations = {
    changeLanguage(state, language = state.languages[0]) {
      state.language = language;
    },
    
    update(state){
      state.update = !state.update
    }

  }

  // your root getters
  export const getters = {
    translate: state => (assetId) => {
      if (!state.i18n) return null;
      let i18n = state.i18n[state.language];
      return( i18n[assetId] ?? assetId );
    }
  }