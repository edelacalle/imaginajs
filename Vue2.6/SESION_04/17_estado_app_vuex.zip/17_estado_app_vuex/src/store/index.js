import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    appName:"",
    contador:0
  },
  getters: {
    getContador(state) {
      return state.contador;
    }
  },
  mutations: {
    ADD_CONTADOR(state) {
      state.contador++;
      Vue.set(state, 'contador', state.contador +1)
    }
  },
  actions: {
    addContador(context) {
      context.commit("ADD_CONTADOR");
    },

    //loadData(context){
    //},

    //fetchGists(context) {
      // return axios.get('https//api.github.com/gists')
      //    .then(response => response.data)
      //    .then(gists => context.commit('', gists))
    //}
  },
  modules: {
  }
})
