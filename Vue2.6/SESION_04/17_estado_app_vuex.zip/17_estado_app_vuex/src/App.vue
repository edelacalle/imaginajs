<template>
  <div id="app">
    <h1>17. Estado de la App ( VueX )</h1>
    <p>Contador es [ {{ this.$store.getters.getContador }} ]</p>
    <p><button @click="addNumber">Incrementa</button></p>
    <HijoComp></HijoComp>
  </div>
</template>

<script>

import HijoComp from './components/HijoComp.vue';


export default {
  name: 'App',
  components: {HijoComp},
  methods:{
    addNumber(){
      console.log("el contador es ",this.$store.getters.getContador )
      this.$store.dispatch('addContador')
    }
  }

}
</script>

<style>

</style>
