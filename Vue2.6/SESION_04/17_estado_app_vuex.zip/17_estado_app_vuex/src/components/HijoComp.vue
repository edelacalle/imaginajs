<template>

  <div class="hijo">
      <h4>Componente Hijo</h4>
      <p>Contador global es [ {{ this.$store.getters.getContador }} ]</p>
      <p><button @click="addHijo">Hijo Incrementa</button></p>
  </div>

</template>

<script>
export default {
  name: 'HijoComp',
  methods:{
    addHijo(){
      this.$store.dispatch('addContador')
    }
  }
}
</script>


<style scoped>

</style>
