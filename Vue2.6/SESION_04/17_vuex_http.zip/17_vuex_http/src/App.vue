<template>
  <div id="app">
    <h1>17_vue.http</h1>
    <p>{{this.$store.getters.getRepos}}</p>
  </div>
</template>

<script>
//import HelloWorld from './components/HelloWorld.vue'

export default {
  name: 'App',
  components: {
  //  HelloWorld
  },
  created(){
    console.log("created",JSON.stringify(this.$store.getters.getRepos))
    this.$store.dispatch('fetchReposSync');
    console.log("created",JSON.stringify(this.$store.getters.getRepos))
  }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
