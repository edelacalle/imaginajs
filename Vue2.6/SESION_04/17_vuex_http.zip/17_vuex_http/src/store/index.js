import Vue from 'vue'
import Vuex from 'vuex'
import axios from 'axios'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    repos:[]
  },
  getters: {
    getRepos(state){
      return state.repos
    }
  },
  mutations: {
    SET_REPOS(state,payload){
      //Vue.set(state, 'repos', payload)
      state.repos = payload
    }
    
  },
  actions: {
    fetchRepos(context) {
      return axios.get('https://api.github.com/users/Unitech/repos')
         .then(response => response.data)
         .then(repos => context.commit('SET_REPOS', repos))
   },

   async fetchReposSync(context) {
    const response = await axios.get('https://api.github.com/users/Unitech/repos')
    const repos = response.data
    const response2 = await axios.get('https://api.github.com/users/edelacalle/repos')
    const repos2 = response2.data
    return context.commit('SET_REPOS', {rep1:repos , rep2:repos2})
    },
  },
  modules: {
  }
})
