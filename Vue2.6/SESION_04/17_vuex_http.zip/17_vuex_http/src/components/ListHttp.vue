<template>
  <h4>Hijo Http</h4>
</template>

<script>
export default {
  name: 'ListHttp',

}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
