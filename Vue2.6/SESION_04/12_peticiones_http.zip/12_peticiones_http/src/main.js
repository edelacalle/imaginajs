import Vue from 'vue'
import App from './App.vue'

import VueResource from 'vue-resource';
Vue.use(VueResource);

Vue.http.interceptors.push(function(request) {
  console.log("soy el interceptor del http", request)
})

Vue.config.productionTip = false

new Vue({
  render: h => h(App),
}).$mount('#app')
