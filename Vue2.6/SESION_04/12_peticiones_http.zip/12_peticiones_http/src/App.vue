<template>
  <div id="app">
      <h1>12 Peticiones http</h1>
      <p>{{ jData }}</p>
  </div>
</template>

<script>

let url = "https://api.github.com/users/Unitech/repos"
export default {
  name: 'App',
  components: {
  },
  data(){
    return{
      jData:{}
    }
  },
  created(){
    this.$root.$http.get(url).then((d)=>this.jData=d)
  }

}
</script>

<style>

</style>
