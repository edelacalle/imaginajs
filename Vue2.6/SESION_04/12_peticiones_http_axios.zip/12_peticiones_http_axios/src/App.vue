<template>
  <div id="app">
      <h1>12 Peticiones Axios</h1>    
      <button @click="loadDif">Opcion Diferida</button>
      <button @click="loadWait">Opcion Inmediata</button>
      <button @click="jData=[]">Clear</button>
      <p>{{ jData }}</p>
  </div>
</template>

<script>

let url  = "https://api.github.com/users/edelacalle/repos"
let url2 = "https://api.github.com/users/Unitech/repos"

export default {
  name: 'App',
  components: {    
  },
  data(){
    return{
      jData:{}
    }
  },
  mounted(){
    // this.axios.get(url).then((data)=>this.jData=data)
  },
  methods:{

    async loadWait(){
      let res   = await this.axios.get(url);
      let res2  = await this.axios.get(url2);

      this.jData = {
        ecalle:res.data.length,
        unitech:res2.data.length
      }
    },

    loadDif(){
      console.log("Inicio Load Diferido")
      this.axios.get(url).then((body)=>{
        console.log("ya tengo los datos del diferido" , body.data.length)
        this.jData = body.data
      })
      console.log("el siguiente mensaje del load diferido")
    }

  }
}
</script>

<style>
</style>
