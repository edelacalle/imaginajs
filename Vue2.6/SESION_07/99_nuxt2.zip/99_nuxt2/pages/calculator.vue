<template>
   <v-card>
      <v-toolbar color="blue-grey darken-4">
        <v-toolbar-title class="white--text">{{ appName }}</v-toolbar-title>
      </v-toolbar>

      <v-card-text class="py-4 blue-grey lighten-4">
        <v-container grid-list-md text-xs-center>
          <v-layout row wrap>
              <calculator-display :formula="formula"></calculator-display>
              <calculator-button
                  v-for="button in buttons"
                  :click-event-name="clickEventName"
                  :color="button.length > 1 ? button[1] : ''"
                  :key="button.id"
                  :symbol="button[0]"
                  @calculator-button-click='processButtonClick'
              >
              </calculator-button>
          </v-layout>
        </v-container>
      </v-card-text>
    </v-card>

</template>

<script>
  import CalculatorDisplay from '../components/CalculatorDisplay.vue';
  import CalculatorButton from '../components/CalculatorButton.vue'

  let buttons = [
    ['AC', 'red darken-3'], ['CE', 'red darken-3'], ['÷'], ['x'],
    ['7'], ['8'], ['9'], ['-'],
    ['4'], ['5'], ['6'], ['+'],
    ['1'], ['2'], ['3'], ['.'],
    ['0'], ['=']
  ];


export default {
 name: 'calculadora-layout',
 components:{CalculatorDisplay, CalculatorButton},
 data() {
  return {
    appName: 'Calculadora',
    buttons: buttons,
    clickEventName: 'calculator-button-click',
    formula: '0',
    isLoading: false

  }
 },
 methods: {
    processButtonClick(symbol) {
      let validFormula;
      switch (symbol) {
        case 'AC':
          return this.setFormula('0');
        case 'CE':
          validFormula = this.formula.slice(0, this.formula.length - 1);
          if (validFormula.length === 0) validFormula = '0';
          return this.setFormula(validFormula);
        case '=':
          validFormula = this.formula.replace(/\÷/g, '/').replace(/\x/g, '*');
          return this.setFormula(eval(validFormula) + '');
        default:
          if (this.validateEntry(this.formula, symbol)) return this.setFormula(this.formula + symbol);
      }
    },
    setFormula(formula) {
      // Should not start with 0
      this.formula = formula.replace(/^[0]*([^0]+)$/, '$1');
    },
    validateEntry(formula, symbol) {
      let expectedFormula = formula + symbol;
      let pattern = '';
      switch (symbol) {
        case '.':
          // More than one .
          if (expectedFormula.match(/\.[\d]*\./)) return false;
          break;
        case '+':
        case 'x':
        case '÷':
          // Should not start
          if (expectedFormula === '0' + symbol) return false;

          // Consecutive operators
          pattern = new RegExp(`[\\+\\-\\÷\\x][\\` + symbol + `]`);
          if (expectedFormula.match(pattern)) return false;
          break;
        case '-':
          // -- not allowed, x- or ÷- are ok
          if (expectedFormula.match(/\-\-/)) return false;
          break;
      }
      return true;
    }
  },

 mounted () {
    // Support keyboard entry
    window.addEventListener('keyup', event => {
      if (event.key.match(/^[\d\+\-\.\=]$/)) return this.processButtonClick(event.key);
      if (event.key === '*') return this.processButtonClick('x');
      if (event.key === '/') return this.processButtonClick('÷');
      if (event.key === 'Delete') return this.processButtonClick('AC');
      if (event.key === 'Backspace') return this.processButtonClick('CE');
      if (event.key === 'Enter') return this.processButtonClick('=');
    });
  }
 
}



/*

 methods: {
    processButtonClick(symbol) {
      let validFormula;
      switch (symbol) {
        case 'AC':
          return this.setFormula('0');
        case 'CE':
          validFormula = this.formula.slice(0, this.formula.length - 1);
          if (validFormula.length === 0) validFormula = '0';
          return this.setFormula(validFormula);
        case '=':
          validFormula = this.formula.replace(/\÷/g, '/').replace(/\x/g, '*');
          return this.setFormula(eval(validFormula) + '');
        default:
          if (this.validateEntry(this.formula, symbol)) return this.setFormula(this.formula + symbol);
      }
    },
    setFormula(formula) {
      // Should not start with 0
      this.formula = formula.replace(/^[0]*([^0]+)$/, '$1');
    },
    validateEntry(formula, symbol) {
      let expectedFormula = formula + symbol;
      let pattern = '';
      switch (symbol) {
        case '.':
          // More than one .
          if (expectedFormula.match(/\.[\d]*\./)) return false;
          break;
        case '+':
        case 'x':
        case '÷':
          // Should not start
          if (expectedFormula === '0' + symbol) return false;

          // Consecutive operators
          pattern = new RegExp(`[\\+\\-\\÷\\x][\\` + symbol + `]`);
          if (expectedFormula.match(pattern)) return false;
          break;
        case '-':
          // -- not allowed, x- or ÷- are ok
          if (expectedFormula.match(/\-\-/)) return false;
          break;
      }
      return true;
    }
  },
  mounted () {
    // Support keyboard entry
    window.addEventListener('keyup', event => {
      if (event.key.match(/^[\d\+\-\.\=]$/)) return this.processButtonClick(event.key);
      if (event.key === '*') return this.processButtonClick('x');
      if (event.key === '/') return this.processButtonClick('÷');
      if (event.key === 'Delete') return this.processButtonClick('AC');
      if (event.key === 'Backspace') return this.processButtonClick('CE');
      if (event.key === 'Enter') return this.processButtonClick('=');
    });
  }
*/


</script>