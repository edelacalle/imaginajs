<template>
  <v-layout>
    <v-flex class="text-center">
      <p>My User</p>
      <v-card class="elevation-12">
                    <v-toolbar dark color="primary">
                       <v-toolbar-title>Login form</v-toolbar-title>
                    </v-toolbar>
                    <v-card-text>
                      <p>los datos de Me: {{ JSON.stringify(this.$store.getters.me)}} </p>
                    
                    </v-card-text>
                 </v-card>
      
    </v-flex>
  </v-layout>
</template>



<script>

export default {
 name: 'me-layout',
 data() {
   return {
 
   };
 },
 methods:{
  login(){
    console.log("metodo login ", this.username, this.password)
    let aux = this.$store.getters.login(this.username,this.password);
    if(aux!= -1 ){
      this.$store.commit('setUser', aux)
      console.log("aux es ", this.$store.getters.isLogin , this.$store.getters.me  )
    }
    
    
  }
 }
};
</script>
