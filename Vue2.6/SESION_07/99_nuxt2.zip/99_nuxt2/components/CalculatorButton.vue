<template>
  <v-flex :class="{ 'xs3': symbol !== '=', 'xs9': symbol === '=' }">
    <v-btn dark :color="color" block large @click="click">
    {{ symbol }}
    </v-btn>
    </v-flex>

</template>

<script>


  export default {
    name: 'calculator-button',
    props: {
    clickEventName: {
      type: String,
      default: 'click'
    },
    color: {
      type: String,
      default: 'grey darken-3'
    },
    symbol: {
      default: ''
    }
  },
  methods: {
    click () {
      this.$emit(this.clickEventName, this.symbol);
    }
  }
  }



</script>

<style>

</style>
