  // holds your root state
  export const state = () => ({
    users:[
      {id:0, username:"user" , pass:"pass" , name:"Enrique de la Calle"  , userGithub:"edelacalle"},
      {id:1, username:"user1", pass:"password1", name:"Usuario1", userGithub:"Unitech"},
      {id:2, username:"user2", pass:"password2", name:"Usuario2",  userGithub:""}
    ],
    nPosLogin:-1,
    username: "vacio",
    userGithub:""
  })
  
  // contains your actions
  export const actions = {
    //setUser({ state, commit }){
    //  commit('setUser', state.nPosLogin)
    //}


  }
  
  // contains your mutations
  export const mutations = {
    setUser(state,nPos){
      state.nPosLogin = nPos;
      if(nPos!= -1 ){
        state.username = state.users[nPos].name;
        state.userGithub = state.users[nPos].userGithub;
      }
    }
  }

  // your root getters
  export const getters = {
    isLogin:state =>  state.nPosLogin != -1 , 
    login: state => ( user , pass ) => {
      let nPos  = state.users.findIndex(r=>(r.username==user && r.pass == pass));
      console.log("nPos", nPos)
      return nPos;
    },
    me: state => (state.nPosLogin != -1 )? state.users[state.nPosLogin]: {} 
  }