<template>
    <h1>hola Imagina {{txt }}</h1>
</template>


<script>
export default {
  name: 'Imagina',
  data(){
    return {
        txt:"Hola mundo"
    }
  }
}
</script>