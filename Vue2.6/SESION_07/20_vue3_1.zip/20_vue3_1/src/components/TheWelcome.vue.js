"use strict";
/* __placeholder__ */
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
Object.defineProperty(exports, "__esModule", { value: true });
var WelcomeItem_vue_1 = require("./WelcomeItem.vue");
var IconDocumentation_vue_1 = require("./icons/IconDocumentation.vue");
var IconTooling_vue_1 = require("./icons/IconTooling.vue");
var IconEcosystem_vue_1 = require("./icons/IconEcosystem.vue");
var IconCommunity_vue_1 = require("./icons/IconCommunity.vue");
var IconSupport_vue_1 = require("./icons/IconSupport.vue");
var _a = await Promise.resolve().then(function () { return require('vue'); }), defineProps = _a.defineProps, defineSlots = _a.defineSlots, defineEmits = _a.defineEmits, defineExpose = _a.defineExpose, defineModel = _a.defineModel, defineOptions = _a.defineOptions, withDefaults = _a.withDefaults;
var __VLS_modelEmitsType;
var __VLS_componentsOption = {};
var __VLS_name;
function __VLS_template() {
    var __VLS_ctx;
    /* Components */
    var __VLS_otherComponents;
    var __VLS_own;
    var __VLS_localComponents;
    var __VLS_components;
    var __VLS_styleScopedClasses;
    /* CSS variable injection */
    /* CSS variable injection end */
    var __VLS_resolvedLocalAndGlobalComponents;
    __VLS_components.WelcomeItem;
    __VLS_components.WelcomeItem;
    __VLS_components.WelcomeItem;
    __VLS_components.WelcomeItem;
    __VLS_components.WelcomeItem;
    __VLS_components.WelcomeItem;
    __VLS_components.WelcomeItem;
    __VLS_components.WelcomeItem;
    __VLS_components.WelcomeItem;
    __VLS_components.WelcomeItem;
    __VLS_components.WelcomeItem;
    __VLS_components.WelcomeItem;
    __VLS_components.WelcomeItem;
    __VLS_components.WelcomeItem;
    __VLS_components.WelcomeItem;
    __VLS_components.WelcomeItem;
    __VLS_components.WelcomeItem;
    __VLS_components.WelcomeItem;
    __VLS_components.WelcomeItem;
    __VLS_components.WelcomeItem;
    // @ts-ignore
    [WelcomeItem_vue_1.default, WelcomeItem_vue_1.default, WelcomeItem_vue_1.default, WelcomeItem_vue_1.default, WelcomeItem_vue_1.default, WelcomeItem_vue_1.default, WelcomeItem_vue_1.default, WelcomeItem_vue_1.default, WelcomeItem_vue_1.default, WelcomeItem_vue_1.default,];
    __VLS_intrinsicElements.template;
    __VLS_intrinsicElements.template;
    __VLS_intrinsicElements.template;
    __VLS_intrinsicElements.template;
    __VLS_intrinsicElements.template;
    __VLS_intrinsicElements.template;
    __VLS_intrinsicElements.template;
    __VLS_intrinsicElements.template;
    __VLS_intrinsicElements.template;
    __VLS_intrinsicElements.template;
    __VLS_intrinsicElements.template;
    __VLS_intrinsicElements.template;
    __VLS_intrinsicElements.template;
    __VLS_intrinsicElements.template;
    __VLS_intrinsicElements.template;
    __VLS_intrinsicElements.template;
    __VLS_intrinsicElements.template;
    __VLS_intrinsicElements.template;
    __VLS_intrinsicElements.template;
    __VLS_intrinsicElements.template;
    __VLS_components.DocumentationIcon;
    __VLS_components.DocumentationIcon;
    // @ts-ignore
    [IconDocumentation_vue_1.default,];
    __VLS_intrinsicElements.a;
    __VLS_intrinsicElements.a;
    __VLS_intrinsicElements.a;
    __VLS_intrinsicElements.a;
    __VLS_intrinsicElements.a;
    __VLS_intrinsicElements.a;
    __VLS_intrinsicElements.a;
    __VLS_intrinsicElements.a;
    __VLS_intrinsicElements.a;
    __VLS_intrinsicElements.a;
    __VLS_intrinsicElements.a;
    __VLS_intrinsicElements.a;
    __VLS_intrinsicElements.a;
    __VLS_intrinsicElements.a;
    __VLS_intrinsicElements.a;
    __VLS_intrinsicElements.a;
    __VLS_intrinsicElements.a;
    __VLS_intrinsicElements.a;
    __VLS_intrinsicElements.a;
    __VLS_intrinsicElements.a;
    __VLS_intrinsicElements.a;
    __VLS_intrinsicElements.a;
    __VLS_intrinsicElements.a;
    __VLS_intrinsicElements.a;
    __VLS_intrinsicElements.a;
    __VLS_intrinsicElements.a;
    __VLS_intrinsicElements.a;
    __VLS_intrinsicElements.a;
    __VLS_intrinsicElements.a;
    __VLS_intrinsicElements.a;
    __VLS_intrinsicElements.a;
    __VLS_intrinsicElements.a;
    __VLS_components.ToolingIcon;
    __VLS_components.ToolingIcon;
    // @ts-ignore
    [IconTooling_vue_1.default,];
    __VLS_intrinsicElements.br;
    __VLS_intrinsicElements.code;
    __VLS_intrinsicElements.code;
    __VLS_components.EcosystemIcon;
    __VLS_components.EcosystemIcon;
    // @ts-ignore
    [IconEcosystem_vue_1.default,];
    __VLS_components.CommunityIcon;
    __VLS_components.CommunityIcon;
    // @ts-ignore
    [IconCommunity_vue_1.default,];
    __VLS_components.SupportIcon;
    __VLS_components.SupportIcon;
    // @ts-ignore
    [IconSupport_vue_1.default,];
    {
        var __VLS_0_1 = {}.WelcomeItem;
        var __VLS_1 = __VLS_asFunctionalComponent(__VLS_0_1, new __VLS_0_1(__assign({})));
        ({}.WelcomeItem);
        ({}.WelcomeItem);
        var __VLS_2_1 = __VLS_1.apply(void 0, __spreadArray([__assign({})], __VLS_functionalComponentArgsRest(__VLS_1), false));
        ({}(__assign({})));
        {
            var __VLS_5_1 = __VLS_intrinsicElements["template"];
            var __VLS_6 = __VLS_elementAsFunctionalComponent(__VLS_5_1);
            var __VLS_7_1 = __VLS_6.apply(void 0, __spreadArray([__assign({})], __VLS_functionalComponentArgsRest(__VLS_6), false));
            ({}(__assign({})));
            {
                (__VLS_3.slots).icon;
                {
                    var __VLS_9_1 = {}.DocumentationIcon;
                    var __VLS_10 = __VLS_asFunctionalComponent(__VLS_9_1, new __VLS_9_1(__assign({})));
                    ({}.DocumentationIcon);
                    var __VLS_11_1 = __VLS_10.apply(void 0, __spreadArray([__assign({})], __VLS_functionalComponentArgsRest(__VLS_10), false));
                    ({}(__assign({})));
                    var __VLS_12 = __VLS_pickFunctionalComponentCtx(__VLS_9_1, __VLS_11_1);
                }
            }
        }
        {
            var __VLS_14_1 = __VLS_intrinsicElements["template"];
            var __VLS_15 = __VLS_elementAsFunctionalComponent(__VLS_14_1);
            var __VLS_16_1 = __VLS_15.apply(void 0, __spreadArray([__assign({})], __VLS_functionalComponentArgsRest(__VLS_15), false));
            ({}(__assign({})));
            {
                (__VLS_3.slots).heading;
            }
        }
        {
            var __VLS_18_1 = __VLS_intrinsicElements["a"];
            var __VLS_19 = __VLS_elementAsFunctionalComponent(__VLS_18_1);
            var __VLS_20_1 = __VLS_19.apply(void 0, __spreadArray([__assign({}, { href: ("https://vuejs.org/"), target: ("_blank"), rel: ("noopener") })], __VLS_functionalComponentArgsRest(__VLS_19), false));
            ({}(__assign({}, { href: ("https://vuejs.org/"), target: ("_blank"), rel: ("noopener") })));
            (__VLS_21.slots).default;
            var __VLS_21 = __VLS_pickFunctionalComponentCtx(__VLS_18_1, __VLS_20_1);
        }
        var __VLS_3 = __VLS_pickFunctionalComponentCtx(__VLS_0_1, __VLS_2_1);
    }
    {
        var __VLS_23_1 = {}.WelcomeItem;
        var __VLS_24 = __VLS_asFunctionalComponent(__VLS_23_1, new __VLS_23_1(__assign({})));
        ({}.WelcomeItem);
        ({}.WelcomeItem);
        var __VLS_25_1 = __VLS_24.apply(void 0, __spreadArray([__assign({})], __VLS_functionalComponentArgsRest(__VLS_24), false));
        ({}(__assign({})));
        {
            var __VLS_28_1 = __VLS_intrinsicElements["template"];
            var __VLS_29 = __VLS_elementAsFunctionalComponent(__VLS_28_1);
            var __VLS_30_1 = __VLS_29.apply(void 0, __spreadArray([__assign({})], __VLS_functionalComponentArgsRest(__VLS_29), false));
            ({}(__assign({})));
            {
                (__VLS_26.slots).icon;
                {
                    var __VLS_32_1 = {}.ToolingIcon;
                    var __VLS_33 = __VLS_asFunctionalComponent(__VLS_32_1, new __VLS_32_1(__assign({})));
                    ({}.ToolingIcon);
                    var __VLS_34_1 = __VLS_33.apply(void 0, __spreadArray([__assign({})], __VLS_functionalComponentArgsRest(__VLS_33), false));
                    ({}(__assign({})));
                    var __VLS_35 = __VLS_pickFunctionalComponentCtx(__VLS_32_1, __VLS_34_1);
                }
            }
        }
        {
            var __VLS_37_1 = __VLS_intrinsicElements["template"];
            var __VLS_38 = __VLS_elementAsFunctionalComponent(__VLS_37_1);
            var __VLS_39_1 = __VLS_38.apply(void 0, __spreadArray([__assign({})], __VLS_functionalComponentArgsRest(__VLS_38), false));
            ({}(__assign({})));
            {
                (__VLS_26.slots).heading;
            }
        }
        {
            var __VLS_41_1 = __VLS_intrinsicElements["a"];
            var __VLS_42 = __VLS_elementAsFunctionalComponent(__VLS_41_1);
            var __VLS_43_1 = __VLS_42.apply(void 0, __spreadArray([__assign({}, { href: ("https://vitejs.dev/guide/features.html"), target: ("_blank"), rel: ("noopener") })], __VLS_functionalComponentArgsRest(__VLS_42), false));
            ({}(__assign({}, { href: ("https://vitejs.dev/guide/features.html"), target: ("_blank"), rel: ("noopener") })));
            (__VLS_44.slots).default;
            var __VLS_44 = __VLS_pickFunctionalComponentCtx(__VLS_41_1, __VLS_43_1);
        }
        {
            var __VLS_46_1 = __VLS_intrinsicElements["a"];
            var __VLS_47 = __VLS_elementAsFunctionalComponent(__VLS_46_1);
            var __VLS_48_1 = __VLS_47.apply(void 0, __spreadArray([__assign({}, { href: ("https://code.visualstudio.com/"), target: ("_blank"), rel: ("noopener") })], __VLS_functionalComponentArgsRest(__VLS_47), false));
            ({}(__assign({}, { href: ("https://code.visualstudio.com/"), target: ("_blank"), rel: ("noopener") })));
            (__VLS_49.slots).default;
            var __VLS_49 = __VLS_pickFunctionalComponentCtx(__VLS_46_1, __VLS_48_1);
        }
        {
            var __VLS_51_1 = __VLS_intrinsicElements["a"];
            var __VLS_52 = __VLS_elementAsFunctionalComponent(__VLS_51_1);
            var __VLS_53_1 = __VLS_52.apply(void 0, __spreadArray([__assign({}, { href: ("https://github.com/johnsoncodehk/volar"), target: ("_blank"), rel: ("noopener") })], __VLS_functionalComponentArgsRest(__VLS_52), false));
            ({}(__assign({}, { href: ("https://github.com/johnsoncodehk/volar"), target: ("_blank"), rel: ("noopener") })));
            (__VLS_54.slots).default;
            var __VLS_54 = __VLS_pickFunctionalComponentCtx(__VLS_51_1, __VLS_53_1);
        }
        {
            var __VLS_56_1 = __VLS_intrinsicElements["a"];
            var __VLS_57 = __VLS_elementAsFunctionalComponent(__VLS_56_1);
            var __VLS_58_1 = __VLS_57.apply(void 0, __spreadArray([__assign({}, { href: ("https://www.cypress.io/"), target: ("_blank"), rel: ("noopener") })], __VLS_functionalComponentArgsRest(__VLS_57), false));
            ({}(__assign({}, { href: ("https://www.cypress.io/"), target: ("_blank"), rel: ("noopener") })));
            (__VLS_59.slots).default;
            var __VLS_59 = __VLS_pickFunctionalComponentCtx(__VLS_56_1, __VLS_58_1);
        }
        {
            var __VLS_61_1 = __VLS_intrinsicElements["a"];
            var __VLS_62 = __VLS_elementAsFunctionalComponent(__VLS_61_1);
            var __VLS_63_1 = __VLS_62.apply(void 0, __spreadArray([__assign({}, { href: ("https://on.cypress.io/component"), target: ("_blank"), rel: ("noopener") })], __VLS_functionalComponentArgsRest(__VLS_62), false));
            ({}(__assign({}, { href: ("https://on.cypress.io/component"), target: ("_blank"), rel: ("noopener") })));
            (__VLS_64.slots).default;
            var __VLS_64 = __VLS_pickFunctionalComponentCtx(__VLS_61_1, __VLS_63_1);
        }
        {
            var __VLS_66_1 = __VLS_intrinsicElements["br"];
            var __VLS_67 = __VLS_elementAsFunctionalComponent(__VLS_66_1);
            var __VLS_68_1 = __VLS_67.apply(void 0, __spreadArray([__assign({})], __VLS_functionalComponentArgsRest(__VLS_67), false));
            ({}(__assign({})));
            var __VLS_69 = __VLS_pickFunctionalComponentCtx(__VLS_66_1, __VLS_68_1);
        }
        {
            var __VLS_71_1 = __VLS_intrinsicElements["code"];
            var __VLS_72 = __VLS_elementAsFunctionalComponent(__VLS_71_1);
            var __VLS_73_1 = __VLS_72.apply(void 0, __spreadArray([__assign({})], __VLS_functionalComponentArgsRest(__VLS_72), false));
            ({}(__assign({})));
            (__VLS_74.slots).default;
            var __VLS_74 = __VLS_pickFunctionalComponentCtx(__VLS_71_1, __VLS_73_1);
        }
        var __VLS_26 = __VLS_pickFunctionalComponentCtx(__VLS_23_1, __VLS_25_1);
    }
    {
        var __VLS_76_1 = {}.WelcomeItem;
        var __VLS_77 = __VLS_asFunctionalComponent(__VLS_76_1, new __VLS_76_1(__assign({})));
        ({}.WelcomeItem);
        ({}.WelcomeItem);
        var __VLS_78_1 = __VLS_77.apply(void 0, __spreadArray([__assign({})], __VLS_functionalComponentArgsRest(__VLS_77), false));
        ({}(__assign({})));
        {
            var __VLS_81_1 = __VLS_intrinsicElements["template"];
            var __VLS_82 = __VLS_elementAsFunctionalComponent(__VLS_81_1);
            var __VLS_83_1 = __VLS_82.apply(void 0, __spreadArray([__assign({})], __VLS_functionalComponentArgsRest(__VLS_82), false));
            ({}(__assign({})));
            {
                (__VLS_79.slots).icon;
                {
                    var __VLS_85_1 = {}.EcosystemIcon;
                    var __VLS_86 = __VLS_asFunctionalComponent(__VLS_85_1, new __VLS_85_1(__assign({})));
                    ({}.EcosystemIcon);
                    var __VLS_87_1 = __VLS_86.apply(void 0, __spreadArray([__assign({})], __VLS_functionalComponentArgsRest(__VLS_86), false));
                    ({}(__assign({})));
                    var __VLS_88 = __VLS_pickFunctionalComponentCtx(__VLS_85_1, __VLS_87_1);
                }
            }
        }
        {
            var __VLS_90_1 = __VLS_intrinsicElements["template"];
            var __VLS_91 = __VLS_elementAsFunctionalComponent(__VLS_90_1);
            var __VLS_92_1 = __VLS_91.apply(void 0, __spreadArray([__assign({})], __VLS_functionalComponentArgsRest(__VLS_91), false));
            ({}(__assign({})));
            {
                (__VLS_79.slots).heading;
            }
        }
        {
            var __VLS_94_1 = __VLS_intrinsicElements["a"];
            var __VLS_95 = __VLS_elementAsFunctionalComponent(__VLS_94_1);
            var __VLS_96_1 = __VLS_95.apply(void 0, __spreadArray([__assign({}, { href: ("https://pinia.vuejs.org/"), target: ("_blank"), rel: ("noopener") })], __VLS_functionalComponentArgsRest(__VLS_95), false));
            ({}(__assign({}, { href: ("https://pinia.vuejs.org/"), target: ("_blank"), rel: ("noopener") })));
            (__VLS_97.slots).default;
            var __VLS_97 = __VLS_pickFunctionalComponentCtx(__VLS_94_1, __VLS_96_1);
        }
        {
            var __VLS_99_1 = __VLS_intrinsicElements["a"];
            var __VLS_100 = __VLS_elementAsFunctionalComponent(__VLS_99_1);
            var __VLS_101_1 = __VLS_100.apply(void 0, __spreadArray([__assign({}, { href: ("https://router.vuejs.org/"), target: ("_blank"), rel: ("noopener") })], __VLS_functionalComponentArgsRest(__VLS_100), false));
            ({}(__assign({}, { href: ("https://router.vuejs.org/"), target: ("_blank"), rel: ("noopener") })));
            (__VLS_102.slots).default;
            var __VLS_102 = __VLS_pickFunctionalComponentCtx(__VLS_99_1, __VLS_101_1);
        }
        {
            var __VLS_104_1 = __VLS_intrinsicElements["a"];
            var __VLS_105 = __VLS_elementAsFunctionalComponent(__VLS_104_1);
            var __VLS_106_1 = __VLS_105.apply(void 0, __spreadArray([__assign({}, { href: ("https://test-utils.vuejs.org/"), target: ("_blank"), rel: ("noopener") })], __VLS_functionalComponentArgsRest(__VLS_105), false));
            ({}(__assign({}, { href: ("https://test-utils.vuejs.org/"), target: ("_blank"), rel: ("noopener") })));
            (__VLS_107.slots).default;
            var __VLS_107 = __VLS_pickFunctionalComponentCtx(__VLS_104_1, __VLS_106_1);
        }
        {
            var __VLS_109_1 = __VLS_intrinsicElements["a"];
            var __VLS_110 = __VLS_elementAsFunctionalComponent(__VLS_109_1);
            var __VLS_111_1 = __VLS_110.apply(void 0, __spreadArray([__assign({}, { href: ("https://github.com/vuejs/devtools"), target: ("_blank"), rel: ("noopener") })], __VLS_functionalComponentArgsRest(__VLS_110), false));
            ({}(__assign({}, { href: ("https://github.com/vuejs/devtools"), target: ("_blank"), rel: ("noopener") })));
            (__VLS_112.slots).default;
            var __VLS_112 = __VLS_pickFunctionalComponentCtx(__VLS_109_1, __VLS_111_1);
        }
        {
            var __VLS_114_1 = __VLS_intrinsicElements["a"];
            var __VLS_115 = __VLS_elementAsFunctionalComponent(__VLS_114_1);
            var __VLS_116_1 = __VLS_115.apply(void 0, __spreadArray([__assign({}, { href: ("https://github.com/vuejs/awesome-vue"), target: ("_blank"), rel: ("noopener") })], __VLS_functionalComponentArgsRest(__VLS_115), false));
            ({}(__assign({}, { href: ("https://github.com/vuejs/awesome-vue"), target: ("_blank"), rel: ("noopener") })));
            (__VLS_117.slots).default;
            var __VLS_117 = __VLS_pickFunctionalComponentCtx(__VLS_114_1, __VLS_116_1);
        }
        var __VLS_79 = __VLS_pickFunctionalComponentCtx(__VLS_76_1, __VLS_78_1);
    }
    {
        var __VLS_119_1 = {}.WelcomeItem;
        var __VLS_120 = __VLS_asFunctionalComponent(__VLS_119_1, new __VLS_119_1(__assign({})));
        ({}.WelcomeItem);
        ({}.WelcomeItem);
        var __VLS_121_1 = __VLS_120.apply(void 0, __spreadArray([__assign({})], __VLS_functionalComponentArgsRest(__VLS_120), false));
        ({}(__assign({})));
        {
            var __VLS_124_1 = __VLS_intrinsicElements["template"];
            var __VLS_125 = __VLS_elementAsFunctionalComponent(__VLS_124_1);
            var __VLS_126_1 = __VLS_125.apply(void 0, __spreadArray([__assign({})], __VLS_functionalComponentArgsRest(__VLS_125), false));
            ({}(__assign({})));
            {
                (__VLS_122.slots).icon;
                {
                    var __VLS_128_1 = {}.CommunityIcon;
                    var __VLS_129 = __VLS_asFunctionalComponent(__VLS_128_1, new __VLS_128_1(__assign({})));
                    ({}.CommunityIcon);
                    var __VLS_130_1 = __VLS_129.apply(void 0, __spreadArray([__assign({})], __VLS_functionalComponentArgsRest(__VLS_129), false));
                    ({}(__assign({})));
                    var __VLS_131 = __VLS_pickFunctionalComponentCtx(__VLS_128_1, __VLS_130_1);
                }
            }
        }
        {
            var __VLS_133_1 = __VLS_intrinsicElements["template"];
            var __VLS_134 = __VLS_elementAsFunctionalComponent(__VLS_133_1);
            var __VLS_135_1 = __VLS_134.apply(void 0, __spreadArray([__assign({})], __VLS_functionalComponentArgsRest(__VLS_134), false));
            ({}(__assign({})));
            {
                (__VLS_122.slots).heading;
            }
        }
        {
            var __VLS_137_1 = __VLS_intrinsicElements["a"];
            var __VLS_138 = __VLS_elementAsFunctionalComponent(__VLS_137_1);
            var __VLS_139_1 = __VLS_138.apply(void 0, __spreadArray([__assign({}, { href: ("https://chat.vuejs.org"), target: ("_blank"), rel: ("noopener") })], __VLS_functionalComponentArgsRest(__VLS_138), false));
            ({}(__assign({}, { href: ("https://chat.vuejs.org"), target: ("_blank"), rel: ("noopener") })));
            (__VLS_140.slots).default;
            var __VLS_140 = __VLS_pickFunctionalComponentCtx(__VLS_137_1, __VLS_139_1);
        }
        {
            var __VLS_142_1 = __VLS_intrinsicElements["a"];
            var __VLS_143 = __VLS_elementAsFunctionalComponent(__VLS_142_1);
            var __VLS_144_1 = __VLS_143.apply(void 0, __spreadArray([__assign({}, { href: ("https://stackoverflow.com/questions/tagged/vue.js"), target: ("_blank"), rel: ("noopener") })], __VLS_functionalComponentArgsRest(__VLS_143), false));
            ({}(__assign({}, { href: ("https://stackoverflow.com/questions/tagged/vue.js"), target: ("_blank"), rel: ("noopener") })));
            (__VLS_145.slots).default;
            var __VLS_145 = __VLS_pickFunctionalComponentCtx(__VLS_142_1, __VLS_144_1);
        }
        {
            var __VLS_147_1 = __VLS_intrinsicElements["a"];
            var __VLS_148 = __VLS_elementAsFunctionalComponent(__VLS_147_1);
            var __VLS_149_1 = __VLS_148.apply(void 0, __spreadArray([__assign({}, { href: ("https://news.vuejs.org"), target: ("_blank"), rel: ("noopener") })], __VLS_functionalComponentArgsRest(__VLS_148), false));
            ({}(__assign({}, { href: ("https://news.vuejs.org"), target: ("_blank"), rel: ("noopener") })));
            (__VLS_150.slots).default;
            var __VLS_150 = __VLS_pickFunctionalComponentCtx(__VLS_147_1, __VLS_149_1);
        }
        {
            var __VLS_152_1 = __VLS_intrinsicElements["a"];
            var __VLS_153 = __VLS_elementAsFunctionalComponent(__VLS_152_1);
            var __VLS_154_1 = __VLS_153.apply(void 0, __spreadArray([__assign({}, { href: ("https://twitter.com/vuejs"), target: ("_blank"), rel: ("noopener") })], __VLS_functionalComponentArgsRest(__VLS_153), false));
            ({}(__assign({}, { href: ("https://twitter.com/vuejs"), target: ("_blank"), rel: ("noopener") })));
            (__VLS_155.slots).default;
            var __VLS_155 = __VLS_pickFunctionalComponentCtx(__VLS_152_1, __VLS_154_1);
        }
        var __VLS_122 = __VLS_pickFunctionalComponentCtx(__VLS_119_1, __VLS_121_1);
    }
    {
        var __VLS_157_1 = {}.WelcomeItem;
        var __VLS_158 = __VLS_asFunctionalComponent(__VLS_157_1, new __VLS_157_1(__assign({})));
        ({}.WelcomeItem);
        ({}.WelcomeItem);
        var __VLS_159_1 = __VLS_158.apply(void 0, __spreadArray([__assign({})], __VLS_functionalComponentArgsRest(__VLS_158), false));
        ({}(__assign({})));
        {
            var __VLS_162_1 = __VLS_intrinsicElements["template"];
            var __VLS_163 = __VLS_elementAsFunctionalComponent(__VLS_162_1);
            var __VLS_164_1 = __VLS_163.apply(void 0, __spreadArray([__assign({})], __VLS_functionalComponentArgsRest(__VLS_163), false));
            ({}(__assign({})));
            {
                (__VLS_160.slots).icon;
                {
                    var __VLS_166_1 = {}.SupportIcon;
                    var __VLS_167 = __VLS_asFunctionalComponent(__VLS_166_1, new __VLS_166_1(__assign({})));
                    ({}.SupportIcon);
                    var __VLS_168_1 = __VLS_167.apply(void 0, __spreadArray([__assign({})], __VLS_functionalComponentArgsRest(__VLS_167), false));
                    ({}(__assign({})));
                    var __VLS_169 = __VLS_pickFunctionalComponentCtx(__VLS_166_1, __VLS_168_1);
                }
            }
        }
        {
            var __VLS_171_1 = __VLS_intrinsicElements["template"];
            var __VLS_172 = __VLS_elementAsFunctionalComponent(__VLS_171_1);
            var __VLS_173_1 = __VLS_172.apply(void 0, __spreadArray([__assign({})], __VLS_functionalComponentArgsRest(__VLS_172), false));
            ({}(__assign({})));
            {
                (__VLS_160.slots).heading;
            }
        }
        {
            var __VLS_175_1 = __VLS_intrinsicElements["a"];
            var __VLS_176 = __VLS_elementAsFunctionalComponent(__VLS_175_1);
            var __VLS_177_1 = __VLS_176.apply(void 0, __spreadArray([__assign({}, { href: ("https://vuejs.org/sponsor/"), target: ("_blank"), rel: ("noopener") })], __VLS_functionalComponentArgsRest(__VLS_176), false));
            ({}(__assign({}, { href: ("https://vuejs.org/sponsor/"), target: ("_blank"), rel: ("noopener") })));
            (__VLS_178.slots).default;
            var __VLS_178 = __VLS_pickFunctionalComponentCtx(__VLS_175_1, __VLS_177_1);
        }
        var __VLS_160 = __VLS_pickFunctionalComponentCtx(__VLS_157_1, __VLS_159_1);
    }
    if (typeof __VLS_styleScopedClasses === 'object' && !Array.isArray(__VLS_styleScopedClasses)) {
    }
    var __VLS_slots;
    return __VLS_slots;
}
var __VLS_internalComponent = (await Promise.resolve().then(function () { return require('vue'); })).defineComponent({
    setup: function () {
        return {
            WelcomeItem: WelcomeItem_vue_1.default,
            DocumentationIcon: IconDocumentation_vue_1.default,
            ToolingIcon: IconTooling_vue_1.default,
            EcosystemIcon: IconEcosystem_vue_1.default,
            CommunityIcon: IconCommunity_vue_1.default,
            SupportIcon: IconSupport_vue_1.default,
        };
    },
    emits: {},
});
exports.default = (await Promise.resolve().then(function () { return require('vue'); })).defineComponent({
    setup: function () {
        return {};
    },
    emits: {},
});
