declare const router: import("vue-router").Router;
export default router;
