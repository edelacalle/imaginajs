<template>
  <div>
    <h1>Home Page</h1>
    <p>Welcome to Nuxt 3, SCSS, Pinia, Vuetify 3.1. boilerplate.</p>
  </div>
</template>
<script lang="ts" setup>
useHead({
  title: "Home Page",
});
</script>
