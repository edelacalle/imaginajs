<template>
    <h1>testsss</h1>
    <h4>{{ contadores }}</h4>
</template>
<script>


export default {
 name: 'test-layout',
 components: {  },
 data() {
   return {
      contadores :[
        {id:1, title:"CPD 1", inicio:0},
        {id:2, title:"CPD 2", inicio:120},
        {id:3, title:"CPD 3", inicio:890},
        {id:4, title:"CPD 4", inicio:0},
      ]
   
   };
 },
};

</script>