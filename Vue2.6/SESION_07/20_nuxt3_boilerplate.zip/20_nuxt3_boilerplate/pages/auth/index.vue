<template>
    <div>
        auth index
    </div>
</template>