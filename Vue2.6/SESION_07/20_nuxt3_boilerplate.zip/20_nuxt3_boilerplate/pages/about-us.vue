<template>
  <div class="page-about_us">
    <h1>About Us</h1>
    <p>
      GitHub:
      <a
        href="https://github.com/burakturkis/nuxt3-scss-pinia-boilerplate-02.2023"
        target="_blank"
        >https://github.com/burakturkis/nuxt3-scss-pinia-boilerplate-02.2023</a
      >
    </p>
  </div>
</template>
<script lang="ts" setup>
useHead({
  title: "About Us",
});
</script>
