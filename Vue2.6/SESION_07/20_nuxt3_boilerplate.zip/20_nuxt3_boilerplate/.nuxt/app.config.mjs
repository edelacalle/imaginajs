
import { defuFn } from 'C:/Vue3/20_nuxt3_boilerplate/node_modules/defu/dist/defu.mjs'

const inlineConfig = {}



export default defuFn(inlineConfig)
