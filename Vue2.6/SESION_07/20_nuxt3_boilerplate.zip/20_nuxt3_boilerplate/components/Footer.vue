<template>
  <footer class="comp-footer">Footer</footer>
</template>
