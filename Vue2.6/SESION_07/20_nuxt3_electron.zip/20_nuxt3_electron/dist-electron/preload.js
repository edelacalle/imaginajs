"use strict";console.log("---- electron/preload.ts ----");
