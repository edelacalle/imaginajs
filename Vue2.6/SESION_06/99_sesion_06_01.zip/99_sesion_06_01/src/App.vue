
<template>
  <div id="app">
    <nav>
      <router-link to="/">Home</router-link> |
      <router-link to="/testing">Testing</router-link> |
      <router-link to="/alumnos">Alumnos</router-link> |
      <router-link to="/secret">Secret</router-link> |
      <router-link to="/github">Github</router-link> |
    </nav>
    
    <router-view/>
  </div>
</template>


<script>

export default {
  name: 'App',

  components: {},
  created(){
  },

  data: () => ({
    //
  }),
};
</script>

<style>
  nav {
    padding: 30px;
  }

  nav a {
    font-weight: bold;
    color: #2c3e50;
  }

  nav a.router-link-exact-active {
    color: #42b983;
  }
</style>./components/ButtonRepo.vue
