import Vue from 'vue'
import VueRouter from 'vue-router'
import HomeView from '../views/HomeView.vue'

import NotFoundView from '../views/NotFoundView.vue'
import TestingView from '../views/TestingView';

import AlumnosView from '../views/AlumnosView';

import SecretView from '@/views/SecretView.vue';
Vue.use(VueRouter)

const routes = [
    {   path: '/404', component: NotFoundView },  
    {
        path: '/testing',
        name: 'testing',
        component: TestingView
      },
      {
        path: '/',
        name: 'home',
        component: HomeView
      },
      {
        path: '/alumnos',
        name: 'alumnos',
        component: AlumnosView
      },
      {
        path: '/secret',
        name: 'secret',
        component: SecretView
      },

    
    { path: '*',  redirect: '/404' }
]

const router = new VueRouter({
  routes
})


export default router