import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    alumnos:[
        {id:1, nombre:"Alumno 1"},
        {id:2, nombre:"Alumno 2"},
        {id:3, nombre:"Alumno 3"},
        {id:4, nombre:"Alumno 4"},
        {id:5, nombre:"Alumno 5"}
    ],
    config:{
        alumnos:{
            headers:[
                
            ]
        }
    },
    appName:"",
    contador:0
  },
  getters: {
    getAlumnos(state){ 
        console.log("llegue a qui ", state)
        return state.alumnos
    },
    getContador(state) {
      return state.contador;
    }
  },
  mutations: {
    ADD_CONTADOR(state) {
      state.contador++;
      Vue.set(state, 'contador', state.contador +1)
    }
  },
  actions: {
    addContador(context) {
      context.commit("ADD_CONTADOR");
    },

    //loadData(context){
    //},

    //fetchGists(context) {
      // return axios.get('https//api.github.com/gists')
      //    .then(response => response.data)
      //    .then(gists => context.commit('', gists))
    //}
  },
  modules: {
  }
})