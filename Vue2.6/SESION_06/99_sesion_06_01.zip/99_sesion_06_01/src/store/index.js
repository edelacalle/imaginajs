import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    alumnos:[
        {id:1, nombre:"Alumno 1"},
        {id:2, nombre:"Alumno 2"},
        {id:3, nombre:"Alumno 3"},
        {id:4, nombre:"Alumno 4"},
        {id:5, nombre:"Alumno 5"}
    ],
    userGitHub:"edelacalle",
    urlGitHub: "https://api.github.com/users/%%USERNAME%%/repos"
  },
  getters: {
    getAlumnos(state){ return state.alumnos },
    getUserGitHub(state){return state.userGitHub},
    getUrlGitHub(state){return state.urlGitHub},

   
  },
  mutations: {
    SET_USERNAME(state,value){
      state.userGitHub = value;
    },
  },
  actions: {
    setUser({ state, commit }){
      commit('SET_USERNAME', state.userGitHub)
    }
  },
  modules: {
  }
})