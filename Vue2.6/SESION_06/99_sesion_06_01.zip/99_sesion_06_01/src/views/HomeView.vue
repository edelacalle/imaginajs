<template>
    <div class="home">
      <h1>Pagina Inicio</h1>
    </div>
  </template>
  
  
  
  <script>
  // @ is an alias to /src
  //import HelloWorld from '@/components/HelloWorld.vue'
  
  export default {
    name: 'HomeView',
    components: {
    //  HelloWorld
    },
    created(){
      console.log("evento creado")
    }
  
  }
  </script>
  