<template>
    <div class="github">
      <h1>Zona Github</h1>
      <v-data-table 
        :headers="head" 
        :items="items"
        locale="es-ES"
      ></v-data-table>
      
      <hr/>
      <br/>
      <v-text-field
        v-model="$store.state.userGitHub"
        name="username"
        label="Usuario"
        type="text"
        placeholder="Usuario del Github"
        required
     ></v-text-field>
     <hr/>
     <br/>
      <v-btn @click="loadResource">Load desde Vue Resource</v-btn>
     <br/>
     
     <br/>
      <v-btn @click="loadAxios">Load desde Axios</v-btn>
     <br/>
     <hr>
     <p>Con boton personalizado enviando desde un servicio</p>
     <br/>
     <br/>
     
     <ButtonRepo :num="items.length"   v-on:onMyClick = "loadRepos"/>


    </div>
  </template>
  
  
  
  <script>
  import { oServ } from '@/services/github.service';
  import ButtonRepo from '@/components/ButtonRepo.vue';
  
  export default {
    name: 'GithubView',
    components: {ButtonRepo},
    data(){
      return {
        head:[
          {  
            text: 'Nombre',
            align: 'start',
            sortable: false,
            value: 'name',
          },
          {  
            text: 'Lenguaje',
            align: 'start',
            sortable: false,
            value: 'language',
          },
        ],
        items:[],
        user:""
      }
    },
    async mounted(){
      this.loadRepos()
    },
    methods:{
      async loadRepos(){
        
        let aux = this.$store.getters.getUserGiHub;
        const res = await oServ.getRepos(aux);
        const jRes = await res.json();
        if( Array.isArray(jRes)){
          this.items = jRes;
        }else{
          this.items = [];
          alert(jRes.message)
        }
          
      },
      async loadResource(){
        let endPoint = this.$store.getters.getUrlGitHub;
        let user = this.$store.getters.getUserGitHub;
        let jRes = await this.$http.get(endPoint.replace("%%USERNAME%%", user));
        if( Array.isArray(jRes.body)){
          this.items = jRes.body;
        }else{
          this.items = [];
          alert(jRes.message)
        }
      },
      async loadAxios(){

        let endPoint = this.$store.getters.getUrlGitHub;
        let user = this.$store.getters.getUserGitHub;
        let jRes = await this.axios.get(endPoint.replace("%%USERNAME%%", user))

        
        if( Array.isArray(jRes.data)){
          this.items = jRes.data;
        }else{
          this.items = [];
          alert(jRes.message)
        }
      }

    }
    
  
  }
  </script>
  