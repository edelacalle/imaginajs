<template>
    <div class="about">
      <h1>Zona de testeo</h1>
    </div>
  </template>
  
  
  
  <script>
  // @ is an alias to /src
  //import HelloWorld from '@/components/HelloWorld.vue'
  
  export default {
    name: 'TestingView',
    components: {
    //  HelloWorld
    },
    created(){
      console.log("evento creado")
    }
  
  }
  </script>
  