export default class  GitHubService{
    _endpoint = "https://api.github.com/users/%%USERNAME%%/repos";
    constructor(){
    }
    version(){
        return "GitHub Services 1.0"
    }

    async getRepos(user){
        return await fetch(this._endpoint.replace("%%USERNAME%%", user) )
    }

}

export const oServ = new GitHubService();