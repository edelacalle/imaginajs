<template>
  <div>
    <v-btn class="text-none" @click="myClick" >
        <v-icon>mdi-home-outline</v-icon>
        Nº Proyectos <b>{{num}}</b> Pulse para refrescar el usuario
    </v-btn>
  </div>
    
  
</template>

<script>
  export default {
    name: 'ButtonRepo',
    data: () => ({
    }),
    props:['num'],
    methods:{
      myClick(){
        this.$emit('onMyClick', ``);
      }
    }

    
  }
</script>
